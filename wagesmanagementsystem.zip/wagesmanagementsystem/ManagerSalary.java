
package wagesmanagementsystem;

public class ManagerSalary extends Salary {
    private Manager manager;

    public ManagerSalary(long salary) {
        super(salary);
    }
    
    
}
