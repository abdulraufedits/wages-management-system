
package wagesmanagementsystem;

public class EmployeeSalary extends Salary{
    private Employee emp;

    public EmployeeSalary(long salary) {
        super(salary);
    }
}
