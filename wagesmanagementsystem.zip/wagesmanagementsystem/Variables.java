
package wagesmanagementsystem;

public class Variables {
    public static final String user = "";
}
